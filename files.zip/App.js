// VOICEBANK ANALYTICS — Interface React principale
// Auteur : Nguebou Temgoua Rayan
// Stack  : React + Tailwind CSS + Recharts + Axios

// Installation :
// npx create-react-app voicebank-ui
// cd voicebank-ui
// npm install axios recharts lucide-react

// Remplace src/App.js par ce fichier

import { useState, useEffect, useRef, useCallback } from "react";
import axios from "axios";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import {
  Mic, MicOff, Sun, Moon, RefreshCw, AlertTriangle,
  TrendingUp, Users, CreditCard, ShieldAlert, ExternalLink,
  Send, Database, Activity, ChevronRight, CheckCircle,
  XCircle, Clock
} from "lucide-react";

// ════════════════════════════════════════
// CONFIGURATION
// ════════════════════════════════════════

const API = "http://localhost:8000";
const POWER_BI_URL = "https://app.powerbi.com"; // remplace par ton vrai lien

const COULEURS = ["#3B82F6","#10B981","#F59E0B","#EF4444","#8B5CF6","#06B6D4","#F97316","#84CC16"];

// ════════════════════════════════════════
// HOOK — APPEL API
// ════════════════════════════════════════

function useAPI() {
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState(null);

  const appeler = useCallback(async (methode, url, data = null) => {
    setChargement(true);
    setErreur(null);
    try {
      const config = { method: methode, url: `${API}${url}` };
      if (data) config.data = data;
      const res = await axios(config);
      return res.data;
    } catch (e) {
      const msg = e.response?.data?.detail || e.message;
      setErreur(msg);
      return null;
    } finally {
      setChargement(false);
    }
  }, []);

  return { appeler, chargement, erreur };
}

// ════════════════════════════════════════
// COMPOSANT — KPI CARD
// ════════════════════════════════════════

function KpiCard({ titre, valeur, icone: Icone, couleur, dark }) {
  return (
    <div className={`rounded-2xl p-5 border transition-all duration-300 hover:scale-105 ${
      dark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200 shadow-sm"
    }`}>
      <div className="flex items-center justify-between mb-3">
        <span className={`text-sm font-medium ${dark ? "text-gray-400" : "text-gray-500"}`}>
          {titre}
        </span>
        <div className={`p-2 rounded-xl`} style={{ backgroundColor: couleur + "20" }}>
          <Icone size={18} style={{ color: couleur }} />
        </div>
      </div>
      <div className={`text-2xl font-bold ${dark ? "text-white" : "text-gray-900"}`}>
        {valeur}
      </div>
    </div>
  );
}

// ════════════════════════════════════════
// COMPOSANT — BOUTON MICRO
// ════════════════════════════════════════

function BoutonMicro({ onTranscription, dark }) {
  const [ecoute, setEcoute]       = useState(false);
  const [statut, setStatut]       = useState("idle"); // idle | recording | processing
  const mediaRecorderRef          = useRef(null);
  const chunksRef                 = useRef([]);

  const demarrerEnregistrement = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];

      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        setStatut("processing");
        const blob = new Blob(chunksRef.current, { type: "audio/wav" });
        const formData = new FormData();
        formData.append("fichier", blob, "audio.wav");

        try {
          const res = await axios.post(`${API}/vocal/transcrire`, formData, {
            headers: { "Content-Type": "multipart/form-data" },
          });
          if (res.data.texte) {
            onTranscription(res.data.texte);
          }
        } catch (e) {
          console.error("Erreur transcription:", e);
        }
        setStatut("idle");
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setEcoute(true);
      setStatut("recording");

      // Arrêt automatique après 8 secondes
      setTimeout(() => {
        if (recorder.state === "recording") {
          recorder.stop();
          setEcoute(false);
        }
      }, 8000);

    } catch (e) {
      alert("Microphone non accessible. Vérifie les permissions du navigateur.");
    }
  };

  const arreterEnregistrement = () => {
    if (mediaRecorderRef.current?.state === "recording") {
      mediaRecorderRef.current.stop();
      setEcoute(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <button
        onClick={ecoute ? arreterEnregistrement : demarrerEnregistrement}
        className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
          ecoute
            ? "bg-red-500 hover:bg-red-600 scale-110"
            : "bg-blue-600 hover:bg-blue-700"
        }`}
      >
        {ecoute && (
          <span className="absolute inset-0 rounded-full bg-red-400 animate-ping opacity-50" />
        )}
        {statut === "processing"
          ? <RefreshCw size={28} className="text-white animate-spin" />
          : ecoute
            ? <MicOff size={28} className="text-white" />
            : <Mic size={28} className="text-white" />
        }
      </button>
      <span className={`text-xs font-medium ${dark ? "text-gray-400" : "text-gray-500"}`}>
        {statut === "recording"  ? "🔴 Enregistrement... (8s max)" :
         statut === "processing" ? "⏳ Transcription..." :
         "Cliquer pour parler"}
      </span>
    </div>
  );
}

// ════════════════════════════════════════
// COMPOSANT — PANEL VOCAL
// ════════════════════════════════════════

function PanelVocal({ dark }) {
  const { appeler, chargement } = useAPI();
  const [question, setQuestion] = useState("");
  const [resultat, setResultat] = useState(null);
  const [historique, setHistorique] = useState([]);

  const poserQuestion = async (texte) => {
    const q = texte || question;
    if (!q.trim()) return;

    const res = await appeler("post", "/vocal/question", { texte: q, langue: "fr" });
    if (res) {
      setResultat(res);
      setHistorique(prev => [{ question: q, total: res.total, source: res.source }, ...prev.slice(0, 4)]);
    }
  };

  const onTranscription = (texte) => {
    setQuestion(texte);
    poserQuestion(texte);
  };

  return (
    <div className={`rounded-2xl border p-6 ${dark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200 shadow-sm"}`}>
      <h2 className={`text-lg font-bold mb-6 ${dark ? "text-white" : "text-gray-900"}`}>
        🎙️ Analyse Vocale
      </h2>

      {/* Bouton micro */}
      <div className="flex justify-center mb-6">
        <BoutonMicro onTranscription={onTranscription} dark={dark} />
      </div>

      {/* Saisie texte */}
      <div className="flex gap-2 mb-4">
        <input
          value={question}
          onChange={e => setQuestion(e.target.value)}
          onKeyDown={e => e.key === "Enter" && poserQuestion()}
          placeholder="Ou tape ta question ici..."
          className={`flex-1 px-4 py-3 rounded-xl border text-sm outline-none transition-all ${
            dark
              ? "bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
              : "bg-gray-50 border-gray-200 text-gray-900 focus:border-blue-500"
          }`}
        />
        <button
          onClick={() => poserQuestion()}
          disabled={chargement}
          className="px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all disabled:opacity-50"
        >
          {chargement ? <RefreshCw size={16} className="animate-spin" /> : <Send size={16} />}
        </button>
      </div>

      {/* Suggestions rapides */}
      <div className="flex flex-wrap gap-2 mb-5">
        {["Top 10 clients", "Credits en defaut", "Transactions frauduleuses", "Alertes critiques"].map(s => (
          <button
            key={s}
            onClick={() => { setQuestion(s); poserQuestion(s); }}
            className={`text-xs px-3 py-1.5 rounded-full border transition-all hover:scale-105 ${
              dark ? "border-gray-600 text-gray-300 hover:border-blue-500" : "border-gray-200 text-gray-600 hover:border-blue-400"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Résultat */}
      {resultat && (
        <div className={`rounded-xl p-4 mb-4 ${dark ? "bg-gray-700" : "bg-gray-50"}`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-sm font-medium ${dark ? "text-gray-300" : "text-gray-600"}`}>
              {resultat.total} résultats
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${
              resultat.source === "rag"
                ? "bg-green-100 text-green-700"
                : "bg-blue-100 text-blue-700"
            }`}>
              {resultat.source === "rag" ? "⚡ RAG" : "🤖 Gemini"} · {resultat.duree_ms}ms
            </span>
          </div>
          <code className={`text-xs block truncate ${dark ? "text-blue-300" : "text-blue-600"}`}>
            {resultat.sql}
          </code>
          {resultat.data?.length > 0 && (
            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr>
                    {resultat.colonnes?.slice(0, 5).map(c => (
                      <th key={c} className={`text-left pb-1 font-medium ${dark ? "text-gray-400" : "text-gray-500"}`}>
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {resultat.data.slice(0, 5).map((row, i) => (
                    <tr key={i} className={dark ? "border-t border-gray-600" : "border-t border-gray-100"}>
                      {resultat.colonnes?.slice(0, 5).map(c => (
                        <td key={c} className={`py-1 pr-2 ${dark ? "text-gray-300" : "text-gray-700"}`}>
                          {String(row[c] ?? "").slice(0, 20)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Historique */}
      {historique.length > 0 && (
        <div>
          <p className={`text-xs font-medium mb-2 ${dark ? "text-gray-400" : "text-gray-500"}`}>Historique</p>
          {historique.map((h, i) => (
            <div key={i} className={`flex items-center justify-between py-1.5 text-xs ${dark ? "text-gray-400" : "text-gray-500"}`}>
              <span className="truncate flex-1">{h.question}</span>
              <span className="ml-2 font-medium">{h.total} lignes</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════
// COMPOSANT — ALERTES FRAUDE
// ════════════════════════════════════════

function PanelAlertes({ dark }) {
  const { appeler } = useAPI();
  const [alertes, setAlertes] = useState([]);
  const [filtre, setFiltre]   = useState("Critique");

  useEffect(() => {
    appeler("get", `/alertes/fraude?niveau=${filtre}&limit=8`).then(res => {
      if (res) setAlertes(res.data);
    });
  }, [filtre]);

  const couleurNiveau = {
    Critique: "text-red-500 bg-red-100",
    Élevé:    "text-orange-500 bg-orange-100",
    Moyen:    "text-yellow-600 bg-yellow-100",
    Faible:   "text-green-600 bg-green-100",
  };

  return (
    <div className={`rounded-2xl border p-6 ${dark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200 shadow-sm"}`}>
      <div className="flex items-center justify-between mb-4">
        <h2 className={`text-lg font-bold ${dark ? "text-white" : "text-gray-900"}`}>
          🚨 Alertes Fraude
        </h2>
        <div className="flex gap-1">
          {["Critique","Élevé","Moyen"].map(n => (
            <button
              key={n}
              onClick={() => setFiltre(n)}
              className={`text-xs px-2.5 py-1 rounded-full transition-all ${
                filtre === n
                  ? "bg-blue-600 text-white"
                  : dark ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-600"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {alertes.length === 0 ? (
          <p className={`text-sm text-center py-4 ${dark ? "text-gray-500" : "text-gray-400"}`}>
            Aucune alerte {filtre}
          </p>
        ) : alertes.map((a, i) => (
          <div key={i} className={`flex items-center justify-between p-3 rounded-xl ${
            dark ? "bg-gray-700" : "bg-gray-50"
          }`}>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${couleurNiveau[a.niveau_alerte] || "text-gray-500 bg-gray-100"}`}>
                  {a.niveau_alerte}
                </span>
                <span className={`text-xs ${dark ? "text-gray-400" : "text-gray-500"}`}>
                  Score : {(a.score_anomalie * 100).toFixed(0)}%
                </span>
              </div>
              <p className={`text-xs truncate ${dark ? "text-gray-300" : "text-gray-600"}`}>
                {a.motif || "Comportement inhabituel"}
              </p>
              <p className={`text-xs ${dark ? "text-gray-500" : "text-gray-400"}`}>
                {a.banque} · {a.ville}
              </p>
            </div>
            <div className={`text-right ml-2`}>
              <p className={`text-sm font-bold ${dark ? "text-white" : "text-gray-900"}`}>
                {a.montant_fcfa ? (a.montant_fcfa / 1000000).toFixed(1) + "M" : "--"}
              </p>
              <p className={`text-xs ${dark ? "text-gray-500" : "text-gray-400"}`}>FCFA</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ════════════════════════════════════════
// COMPOSANT — GRAPHIQUES
// ════════════════════════════════════════

function PanelGraphiques({ dark, stats }) {
  if (!stats) return null;
  const { clients_par_banque = [], transactions_mois = [] } = stats;

  const dataClients = clients_par_banque.slice(0, 6).map(b => ({
    name: b.banque?.replace(" Cameroun","").replace("Société Générale","SG") || "",
    clients: b.nb_clients,
    diaspora: b.nb_diaspora,
  }));

  const dataMois = transactions_mois.slice(0, 8).map(m => ({
    mois: m.mois ? new Date(m.mois).toLocaleDateString("fr", { month: "short" }) : "",
    transactions: m.nb_transactions,
    fraudes: m.nb_fraudes,
  }));

  const axisStyle = { fill: dark ? "#9CA3AF" : "#6B7280", fontSize: 11 };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

      {/* Clients par banque */}
      <div className={`rounded-2xl border p-5 ${dark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200 shadow-sm"}`}>
        <h3 className={`text-sm font-bold mb-4 ${dark ? "text-white" : "text-gray-900"}`}>
          Clients par banque
        </h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={dataClients}>
            <CartesianGrid strokeDasharray="3 3" stroke={dark ? "#374151" : "#F3F4F6"} />
            <XAxis dataKey="name" tick={axisStyle} />
            <YAxis tick={axisStyle} />
            <Tooltip
              contentStyle={{ backgroundColor: dark ? "#1F2937" : "#fff", border: "none", borderRadius: 8 }}
              labelStyle={{ color: dark ? "#fff" : "#111" }}
            />
            <Bar dataKey="clients"  fill="#3B82F6" radius={[4,4,0,0]} name="Total" />
            <Bar dataKey="diaspora" fill="#10B981" radius={[4,4,0,0]} name="Diaspora" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Transactions mensuelles */}
      <div className={`rounded-2xl border p-5 ${dark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200 shadow-sm"}`}>
        <h3 className={`text-sm font-bold mb-4 ${dark ? "text-white" : "text-gray-900"}`}>
          Transactions mensuelles
        </h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={dataMois}>
            <CartesianGrid strokeDasharray="3 3" stroke={dark ? "#374151" : "#F3F4F6"} />
            <XAxis dataKey="mois" tick={axisStyle} />
            <YAxis tick={axisStyle} />
            <Tooltip
              contentStyle={{ backgroundColor: dark ? "#1F2937" : "#fff", border: "none", borderRadius: 8 }}
            />
            <Line type="monotone" dataKey="transactions" stroke="#3B82F6" strokeWidth={2} dot={false} name="Total" />
            <Line type="monotone" dataKey="fraudes"      stroke="#EF4444" strokeWidth={2} dot={false} name="Fraudes" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ════════════════════════════════════════
// APP PRINCIPALE
// ════════════════════════════════════════

export default function App() {
  const [dark, setDark]       = useState(true);
  const [dashboard, setDashboard] = useState(null);
  const [stats, setStats]     = useState(null);
  const [onglet, setOnglet]   = useState("vocal"); // vocal | alertes | credits | graphiques
  const { appeler }           = useAPI();

  useEffect(() => {
    appeler("get", "/dashboard").then(res => res && setDashboard(res.data));
    appeler("get", "/stats/global").then(res => res && setStats(res.data));
  }, []);

  const kpis = dashboard ? [
    { titre: "Total Clients",       valeur: dashboard.total_clients?.toLocaleString("fr"),       icone: Users,       couleur: "#3B82F6" },
    { titre: "Transactions",        valeur: dashboard.total_transactions?.toLocaleString("fr"),   icone: Activity,    couleur: "#10B981" },
    { titre: "Fraudes détectées",   valeur: dashboard.total_fraudes?.toLocaleString("fr"),        icone: ShieldAlert, couleur: "#EF4444" },
    { titre: "Encours crédit (M)",  valeur: dashboard.encours_credit_fcfa ? (dashboard.encours_credit_fcfa / 1_000_000_000).toFixed(1) + "Mds" : "--", icone: CreditCard, couleur: "#F59E0B" },
  ] : [];

  const onglets = [
    { id: "vocal",      label: "🎙️ Vocal",     },
    { id: "alertes",    label: "🚨 Alertes",    },
    { id: "graphiques", label: "📊 Graphiques", },
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${dark ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"}`}>

      {/* Header */}
      <header className={`border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10 backdrop-blur-md ${
        dark ? "bg-gray-900/90 border-gray-700" : "bg-white/90 border-gray-200"
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Database size={16} className="text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold">VoiceBank Analytics</h1>
            <p className={`text-xs ${dark ? "text-gray-400" : "text-gray-500"}`}>
              Nguebou Temgoua Rayan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Bouton Power BI */}
          <button
            onClick={() => window.open(POWER_BI_URL, "_blank")}
            className="flex items-center gap-2 px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-medium rounded-xl transition-all hover:scale-105"
          >
            <TrendingUp size={14} />
            Power BI
            <ExternalLink size={12} />
          </button>

          {/* Toggle dark/light */}
          <button
            onClick={() => setDark(!dark)}
            className={`p-2.5 rounded-xl transition-all ${dark ? "bg-gray-700 hover:bg-gray-600" : "bg-gray-100 hover:bg-gray-200"}`}
          >
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6">

        {/* KPIs */}
        {kpis.length > 0 && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {kpis.map((k, i) => <KpiCard key={i} {...k} dark={dark} />)}
          </div>
        )}

        {/* Onglets */}
        <div className={`flex gap-1 mb-6 p-1 rounded-xl w-fit ${dark ? "bg-gray-800" : "bg-gray-100"}`}>
          {onglets.map(o => (
            <button
              key={o.id}
              onClick={() => setOnglet(o.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                onglet === o.id
                  ? "bg-blue-600 text-white shadow"
                  : dark ? "text-gray-400 hover:text-white" : "text-gray-500 hover:text-gray-900"
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>

        {/* Contenu par onglet */}
        {onglet === "vocal" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <PanelVocal dark={dark} />
            <PanelAlertes dark={dark} />
          </div>
        )}

        {onglet === "alertes" && (
          <div className="max-w-2xl">
            <PanelAlertes dark={dark} />
          </div>
        )}

        {onglet === "graphiques" && (
          <PanelGraphiques dark={dark} stats={stats} />
        )}

      </main>
    </div>
  );
}
